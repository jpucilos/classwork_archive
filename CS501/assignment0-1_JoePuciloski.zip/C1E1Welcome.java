public class C1E1Welcome {
    public static void main(String[] args) {
        System.out.println("This Program prints three statements, there is no user input.");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Computer Science");
        System.out.println("Programming is fun");
    }
}